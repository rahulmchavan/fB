package com.flightapp.serviceimpl;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.entity.BookingDetails;
import com.flightapp.entity.Passenger;
import com.flightapp.repository.BookingRepository;
import com.flightapp.repository.PassengerRepository;
import com.flightapp.service.BookingService;

@Service
public class BookingServiceImpl implements BookingService {
	
	@Autowired
	private BookingRepository repo;
	
	@Autowired
	private PassengerRepository passengerRepo;

	@Override
	public BookingDetails bookTicket(BookingDetails details) {
		details.setPnrNumber(generatePNR());
		List<Passenger> passengerDetails = details.getDetails();
		for(Passenger passenger:passengerDetails) {
			passenger.setPnrNumber(details.getPnrNumber());
			passengerRepo.save(passenger);
		}
		BookingDetails detailsAfter = repo.save(details);
		return detailsAfter;
	}

	@Override
	public List<BookingDetails> getBookingHistoryById(Integer userId) {
		return repo.getBookingHistoryById(userId);
	}

	@Override
	public List<BookingDetails> getBookingHistoryByMailId(String mailId) {
		return repo.getBookingHistoryByMailId(mailId);
	}

	@Override
	public List<BookingDetails> getBookingHistoryByPNRNUMBER(Integer pnrNumber) {
		return repo.getBookingHistoryByPNRNUMBER(pnrNumber);
	}

	@Override
	public BookingDetails cancelTicket(Integer pnrNumber) {
		Passenger passenger=passengerRepo.getPassengerDetails(pnrNumber);
		passenger.setBookingStatus("cancelled");
		passengerRepo.save(passenger);
		BookingDetails details = repo.downloadTicketDetails(pnrNumber);
		details.setBookingStatus("cancelled");
		details = repo.save(details);
		return details;
		
	}

	@Override
	public BookingDetails downloadTicketDetails(Integer pnrNumber) {
		return repo.downloadTicketDetails(pnrNumber);
	}
	
	public Integer generatePNR() {
		 Random random=new Random();
		    int randomNumber=0;
		    boolean loop=true;
		    while(loop) {
		        randomNumber=random.nextInt();
		        if(Integer.toString(randomNumber).length()==10 && !Integer.toString(randomNumber).startsWith("-")) {
		            loop=false;
		        }
		        }
	    return randomNumber;
	}

}
