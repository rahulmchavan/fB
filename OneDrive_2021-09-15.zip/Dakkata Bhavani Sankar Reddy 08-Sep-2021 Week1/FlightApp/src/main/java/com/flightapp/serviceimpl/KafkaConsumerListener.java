package com.flightapp.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.flightapp.entity.BookingDetails;
import com.flightapp.entity.Passenger;
import com.flightapp.repository.BookingRepository;
import com.flightapp.repository.PassengerRepository;


@Service
public class KafkaConsumerListener {

    private static final String TOPIC = "kafka_topic";
    
    @Autowired
	private BookingRepository repo;
    
	@Autowired
	private PassengerRepository passengerRepo;

    @KafkaListener(topics = TOPIC, groupId="group_id", containerFactory = "userKafkaListenerFactory")

    public void consumeJson(BookingDetails bookDetails) {
        System.out.println("Consumed JSON Message: " + bookDetails);
        Passenger passenger=passengerRepo.getPassengerDetails(bookDetails.getPnrNumber());
		passenger.setBookingStatus("cancelled");
		passengerRepo.save(passenger);
		BookingDetails details = repo.downloadTicketDetails(bookDetails.getPnrNumber());
		details.setBookingStatus("cancelled");
		details = repo.save(details);
    }
    
}