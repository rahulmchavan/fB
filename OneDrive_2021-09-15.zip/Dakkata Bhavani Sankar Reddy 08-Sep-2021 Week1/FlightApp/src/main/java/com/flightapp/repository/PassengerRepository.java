package com.flightapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.flightapp.entity.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger, Integer> {
	
	@Query("select m from Passenger m where m.bookingStatus='booked' and m.pnrNumber=:pnrNumber ")
	public Passenger getPassengerDetails(Integer pnrNumber);
}
