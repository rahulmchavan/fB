package com.flightapp.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.flightapp.entity.BookingDetails;

@Repository
public interface BookingRepository extends JpaRepository<BookingDetails, Integer> {

	@Query("select m from BookingDetails m where m.bookingStatus='booked' and m.userId=:userId ")
	public List<BookingDetails> getBookingHistoryById(Integer userId);

	@Query("select m from BookingDetails m where m.bookingStatus='booked' and m.userEmail=:mailId ")
	public List<BookingDetails> getBookingHistoryByMailId(String mailId);

	@Query("select m from BookingDetails m where m.bookingStatus='booked' and m.pnrNumber=:pnrNumber ")
	public List<BookingDetails> getBookingHistoryByPNRNUMBER(Integer pnrNumber);

	@Query("select m from BookingDetails m where m.bookingStatus='booked' and m.pnrNumber=:pnrNumber ")
	public BookingDetails downloadTicketDetails(Integer pnrNumber);
}
