package com.flightapp.entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Passenger {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String passengerName;
	private int passengerAge;
	private String gender;
	private String bookingStatus;
	private Double luggage;
	private Integer pnrNumber;
	
	public Passenger() {
		
	}

	public Passenger(Integer id, String passengerName, int passengerAge, String gender, String bookingStatus,
			Double luggage,Integer pnrNumber) {
		super();
		this.id = id;
		this.passengerName = passengerName;
		this.passengerAge = passengerAge;
		this.gender = gender;
		this.bookingStatus = bookingStatus;
		this.luggage = luggage;
		this.pnrNumber=pnrNumber;
	}

	public Integer getPnrNumber() {
		return pnrNumber;
	}
	public void setPnrNumber(Integer pnrNumber) {
		this.pnrNumber = pnrNumber;
		
	}
	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getPassengerAge() {
		return passengerAge;
	}

	public void setPassengerAge(int passengerAge) {
		this.passengerAge = passengerAge;
	}

	public Double getLuggage() {
		return luggage;
	}

	public void setLuggage(Double luggage) {
		this.luggage = luggage;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	@Override
	public String toString() {
		return "Passenger [id=" + id + ", passengerName=" + passengerName + ", passengerAge=" + passengerAge
				+ ", gender=" + gender + ", bookingStatus=" + bookingStatus + ", luggage=" + luggage + "]";
	}

	

}