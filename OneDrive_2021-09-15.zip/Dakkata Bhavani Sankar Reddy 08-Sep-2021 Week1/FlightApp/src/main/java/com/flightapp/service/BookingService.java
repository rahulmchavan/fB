package com.flightapp.service;

import java.util.List;

import com.flightapp.entity.BookingDetails;

public interface BookingService {

	public BookingDetails bookTicket(BookingDetails details);
	
	public List<BookingDetails> getBookingHistoryById(Integer userId);
	
	public List<BookingDetails> getBookingHistoryByMailId(String mailId);
	
	public List<BookingDetails> getBookingHistoryByPNRNUMBER(Integer pnrNumber);
	
	public BookingDetails cancelTicket(Integer pnrNumber);
	
	public BookingDetails downloadTicketDetails(Integer pnrNumber);
	
}
