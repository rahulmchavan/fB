package com.flightApp.adminservice.serviceImpl;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.flightApp.adminservice.adminrepository.FlightRepository;
import com.flightApp.adminservice.entities.Airline;
import com.flightApp.adminservice.entities.Flight;
import com.flightApp.adminservice.exceptions.RecordAlreadyPresentException;
import com.flightApp.adminservice.exceptions.RecordNotFoundException;
import com.flightApp.adminservice.service.FlightService;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	private FlightRepository flightRepository;
	
	
	@Override
	public Flight viewFlight(Integer flightId) {
		Optional<Flight> findById = flightRepository.findById(flightId);
		if (findById.isPresent()) {
			return findById.get();
		}
		else {
			throw new RecordNotFoundException(" Flight with Flight ID: " + flightId + "not exists");
	    }
	}

	@Override
	public List<Flight> viewAllFlights() {
		return flightRepository.getAllFlightDetails();
	}

	@Override
	public ResponseEntity<?> addFlight(Flight flight) {
		Optional<Flight> findById = flightRepository.findById(flight.getFlightId());
		try {
		if (!findById.isPresent()) {
			flight=flightRepository.save(flight);
			return new ResponseEntity<Flight>(flight,HttpStatus.OK);
		} 
		else
			throw new RecordAlreadyPresentException(
					"Flight with Id : " + flight.getAirlineId() + " already present");
	     }
		catch(RecordAlreadyPresentException e)
		{
			return new ResponseEntity<Flight>(flight,HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public Flight modifyFlight(Flight flight) {
		Optional<Flight> findById = flightRepository.findById(flight.getFlightId());
		if (findById.isPresent()) {
			flightRepository.save(flight);
		} 
		else
			throw new RecordNotFoundException("Flight with Id: " + flight.getAirlineId() + " not exists");
		return flight;
	}

	@Override
	public String removeFlight(Integer flightId) {
		Optional<Flight> findById = flightRepository.findById(flightId);
		if (findById.isPresent()) {
			flightRepository.deleteById(flightId);
			return "Flight Deleted";
		} else
			throw new RecordNotFoundException("flightRepository with Id: " + flightId + " not exists");
	}

	@Override
	public List<Flight> getFlightDetails(Flight flight) {
		List<Flight> listFlightDetails = flightRepository.getFlightDetails(flight.getFromPlace(),flight.getToPlace(),flight.getEndDateTime());
		return listFlightDetails;
	}
	
	@Override
	public Flight blockFlight(Integer flightId) {
	Flight flight =flightRepository.getFlightDetailsById(flightId);
	flight.setIsblocked("true");
	 flight=flightRepository.save(flight);
	 return flight;
}

}
