package com.flightApp.adminservice.adminrepository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.flightApp.adminservice.entities.Flight;

public interface FlightRepository extends JpaRepository<Flight, Integer> {
	
	@Query("select m from Flight m where m.fromPlace=:fromPlace and m.toPlace=:toPlace and DATE(m.endDateTime)=:date and m.isblocked='false' and m.statusId=1")
	public List<Flight> getFlightDetails(String fromPlace,String toPlace,Date date);
	
	@Query("select m from Flight m where m.flightId=:flightId and m.isblocked='false' and m.statusId=1 ")
	public Flight getFlightDetailsById(Integer flightId);
	
	@Query("select m from Flight m where m.isblocked='false' and m.statusId=1 ")
	public List<Flight> getAllFlightDetails();

}
