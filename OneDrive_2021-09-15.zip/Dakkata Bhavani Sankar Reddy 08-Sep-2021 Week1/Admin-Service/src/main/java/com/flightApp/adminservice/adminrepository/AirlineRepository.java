package com.flightApp.adminservice.adminrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightApp.adminservice.entities.Airline;

public interface AirlineRepository extends JpaRepository<Airline, Integer> {

}
