package com.flightApp.adminservice;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PasswordEncoder encoder = new BCryptPasswordEncoder();

        String encodedPwd = encoder.encode("test2020");

        System.out.println("EncodedPwd: "+encodedPwd);
	}

}
