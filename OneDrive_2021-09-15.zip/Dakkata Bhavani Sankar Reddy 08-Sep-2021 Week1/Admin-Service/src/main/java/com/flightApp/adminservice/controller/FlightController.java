package com.flightApp.adminservice.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.flightApp.adminservice.entities.Flight;
import com.flightApp.adminservice.exceptions.RecordAlreadyPresentException;
import com.flightApp.adminservice.exceptions.RecordNotFoundException;
import com.flightApp.adminservice.service.FlightService;

@RestController
public class FlightController {
	
	@Autowired
	private FlightService flightService;
	
	@PostMapping("/scheduleFlight")
	@ExceptionHandler(RecordAlreadyPresentException.class)
	public ResponseEntity<?> scheduleFlight(@RequestBody Flight flight) {
		ResponseEntity<?> flightData=flightService.addFlight(flight);
		return new ResponseEntity<Object>(flightData, HttpStatus.OK);
	}

	@GetMapping("/allFlight")
	@Cacheable(value = "flightList")
	public Iterable<Flight> viewAllFlights() {
		return flightService.viewAllFlights();
	}

	@GetMapping("/viewScheduleFlight/{id}")
	//@Cacheable(key = "#id", value = "flightList")
	@ExceptionHandler(RecordNotFoundException.class)
	public Flight viewScheduleFlight(@PathVariable("id") Integer flightNo) {
		return flightService.viewFlight(flightNo);
	}

	@PutMapping("/updateScheduleFlight")
	@ExceptionHandler(RecordNotFoundException.class)
	public void updateScheduleFlight(@RequestBody Flight flight) {
		flightService.modifyFlight(flight);
	}

	@DeleteMapping("/deleteScheduleFlight/{id}")
	//@CacheEvict(key = "#id", value = "flightList")
	@ExceptionHandler(RecordNotFoundException.class)
	public void deleteScheduleFlight(@PathVariable("id") Integer flightNo) {
		flightService.removeFlight(flightNo);
	}
	
	@GetMapping("/getFlightDetails/{fromPlace}/{toPlace}/{depatureDate}")
     public List<Flight> getFlightDetails(@PathVariable("fromPlace") String from,@PathVariable("toPlace") String to,@PathVariable("depatureDate") String date) throws ParseException{
		SimpleDateFormat dbFormat= new SimpleDateFormat("yyyy-MM-dd");
		Flight flight = new Flight();
		flight.setFromPlace(from);
		flight.setToPlace(to);
		flight.setEndDateTime(dbFormat.parse(date));
		return flightService.getFlightDetails(flight);
    	 
     }
	
	@GetMapping("/blockFlight/{id}")
    public Flight blockFlight(@PathVariable("id") Integer flightId){
		return flightService.blockFlight(flightId);
   	 
    }
	
	
}
