package com.flightApp.adminservice.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.flightApp.adminservice.entities.Airline;

@Service
public interface AirlineService {


	public  Airline viewAirline(Integer airlineId);

	public List<Airline> viewAllAirline();

	public ResponseEntity<Airline> addAirline(Airline airline);

	public Airline modifyAirline(Airline airline);

	public String removeAirline(String airlineId);

	
	
}
