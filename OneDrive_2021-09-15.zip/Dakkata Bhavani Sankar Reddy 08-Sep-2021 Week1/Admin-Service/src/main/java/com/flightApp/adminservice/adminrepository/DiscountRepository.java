package com.flightApp.adminservice.adminrepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightApp.adminservice.entities.Discount;

public interface DiscountRepository extends JpaRepository<Discount, Integer> {

}
