package com.flightApp.adminservice.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Discount {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer discountId;
	private String  discountCoupon;
	private float   discountPrice;
	
	public Discount() {
		
	}
	
	public Discount(Integer discountId, String discountCoupon, float discountPrice) {
		super();
		this.discountId = discountId;
		this.discountCoupon = discountCoupon;
		this.discountPrice = discountPrice;
	}
	public Integer getDiscountId() {
		return discountId;
	}
	public void setDiscountId(Integer discountId) {
		this.discountId = discountId;
	}
	public String getDiscountCoupon() {
		return discountCoupon;
	}
	public void setDiscountCoupon(String discountCoupon) {
		this.discountCoupon = discountCoupon;
	}
	public float getDiscountPrice() {
		return discountPrice;
	}
	public void setDiscountPrice(float discountPrice) {
		this.discountPrice = discountPrice;
	}
	@Override
	public String toString() {
		return "Discount [discountId=" + discountId + ", discountCoupon=" + discountCoupon + ", discountPrice="
				+ discountPrice + "]";
	}

}
