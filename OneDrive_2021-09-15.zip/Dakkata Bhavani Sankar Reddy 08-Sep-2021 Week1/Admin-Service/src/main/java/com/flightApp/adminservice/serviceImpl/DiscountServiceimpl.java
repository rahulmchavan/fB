package com.flightApp.adminservice.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightApp.adminservice.adminrepository.DiscountRepository;
import com.flightApp.adminservice.entities.Airline;
import com.flightApp.adminservice.entities.Discount;
import com.flightApp.adminservice.exceptions.RecordNotFoundException;
import com.flightApp.adminservice.service.DiscountService;

@Service
public class DiscountServiceimpl implements DiscountService {

	
	@Autowired
	private DiscountRepository repo;
	
	@Override
	public Discount saveDiscount(Discount discount) {
		// TODO Auto-generated method stub
		return repo.save(discount);
	}

	@Override
	public String deleteDiscountCoupon(Integer Id) {
		Optional<Discount> findById = repo.findById(Id);
		if (findById.isPresent()) {
			repo.deleteById(Id);
			return "Coupon Deleted";
		} else
			throw new RecordNotFoundException("Coupon with Id: " + Id + " not exists");

	}

}
