package com.flightApp.adminservice.entities;

import java.io.Serializable;
import java.sql.Blob;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Airline implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8808908330405113336L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer airlineId;
	private String airlineNumber;
	private String  airline;
	private Blob  airlineLogo;
	private String  address;
	private String  phoneNumber;
	private Integer statusId;
	public Airline() {
		
	}
	
	public Airline(String airline, Blob airlineLogo, String address, String phoneNumber,String airlineNumber,Integer statusId) {
		super();
		this.airline = airline;
		this.airlineLogo = airlineLogo;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.airlineNumber=airlineNumber;
		this.statusId=statusId;
	}
	public Integer getAirlineId() {
		return airlineId;
	}
	public void setAirlineId(Integer airlineId) {
		this.airlineId = airlineId;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Blob getAirlineLogo() {
		return airlineLogo;
	}

	public void setAirlineLogo(Blob airlineLogo) {
		this.airlineLogo = airlineLogo;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAirlineNumber() {
		return airlineNumber;
	}

	public void setAirlineNumber(String airlineNumber) {
		this.airlineNumber = airlineNumber;
	}

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((airline == null) ? 0 : airline.hashCode());
		result = prime * result + ((airlineId == null) ? 0 : airlineId.hashCode());
		result = prime * result + ((airlineLogo == null) ? 0 : airlineLogo.hashCode());
		result = prime * result + ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Airline other = (Airline) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (airline == null) {
			if (other.airline != null)
				return false;
		} else if (!airline.equals(other.airline))
			return false;
		if (airlineId == null) {
			if (other.airlineId != null)
				return false;
		} else if (!airlineId.equals(other.airlineId))
			return false;
		if (airlineLogo == null) {
			if (other.airlineLogo != null)
				return false;
		} else if (!airlineLogo.equals(other.airlineLogo))
			return false;
		if (phoneNumber == null) {
			if (other.phoneNumber != null)
				return false;
		} else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Airline [airlineId=" + airlineId + ", airline=" + airline + ", airlineLogo=" + airlineLogo
				+ ", address=" + address + ", phoneNumber=" + phoneNumber + "]";
	}
	
	
	
}
