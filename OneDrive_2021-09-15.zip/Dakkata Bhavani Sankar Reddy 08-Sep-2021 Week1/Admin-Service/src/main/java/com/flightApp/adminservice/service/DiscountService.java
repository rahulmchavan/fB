package com.flightApp.adminservice.service;

import org.springframework.stereotype.Service;

import com.flightApp.adminservice.entities.Discount;

@Service
public interface DiscountService {
	
	public Discount saveDiscount(Discount discount);
	
	public String deleteDiscountCoupon(Integer Id);

}
