package com.flightApp.adminservice.exceptions;
public class RecordNotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5230766037142360923L;

	public RecordNotFoundException(String s) {
		super(s);
	}

}