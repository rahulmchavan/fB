package com.flightApp.adminservice.exceptions;
public class RecordAlreadyPresentException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6232790556394882735L;

	public RecordAlreadyPresentException(String s) {
		super(s);
	}
}