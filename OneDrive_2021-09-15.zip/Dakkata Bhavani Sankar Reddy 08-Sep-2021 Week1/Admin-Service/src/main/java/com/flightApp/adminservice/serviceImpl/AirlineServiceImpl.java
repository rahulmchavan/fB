package com.flightApp.adminservice.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.flightApp.adminservice.adminrepository.AirlineRepository;
import com.flightApp.adminservice.entities.Airline;
import com.flightApp.adminservice.exceptions.RecordAlreadyPresentException;
import com.flightApp.adminservice.exceptions.RecordNotFoundException;
import com.flightApp.adminservice.service.AirlineService;

@Service
public class AirlineServiceImpl implements AirlineService{

	
	@Autowired
	private AirlineRepository airlineRepository;
	

	@Override
	public Airline viewAirline(Integer airlineId) {
		Optional<Airline> findById = airlineRepository.findById(airlineId);
		if (findById.isPresent()) {
			return findById.get();
		}
		else {
			throw new RecordNotFoundException("Airline with Airline ID: " + airlineId + "not exists");
	    }
	}

	@Override
	public List<Airline> viewAllAirline() {
		return airlineRepository.findAll();
	}

	@Override
	public ResponseEntity<Airline> addAirline(Airline airline) {
		Optional<Airline> findById = airlineRepository.findById(airline.getAirlineId());
		try {
		if (!findById.isPresent()) {
			airline=airlineRepository.save(airline);
			return new ResponseEntity<Airline>(airline,HttpStatus.OK);
		} 
		else
			throw new RecordAlreadyPresentException(
					"Airline with Id : " + airline.getAirlineId() + " already present");
	     }
		catch(RecordAlreadyPresentException e)
		{
			return new ResponseEntity<Airline>(airline,HttpStatus.NOT_FOUND);
		}
		
	}

	@Override
	public Airline modifyAirline(Airline airline) {
		
		Optional<Airline> findById = airlineRepository.findById(airline.getAirlineId());
		if (findById.isPresent()) {
			airlineRepository.save(airline);
		} 
		else
			throw new RecordNotFoundException("Airline with Id: " + airline.getAirlineId() + " not exists");
		return airline;
	}

	@Override
	public String removeAirline(String airlineId) {
		Optional<Airline> findById = airlineRepository.findById(Integer.parseInt(airlineId));
		if (findById.isPresent()) {
			airlineRepository.deleteById(Integer.parseInt(airlineId));
			return "Airline Deleted";
		} else
			throw new RecordNotFoundException("Airline with Id: " + airlineId + " not exists");

	}

}
