package com.flightApp.adminservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.flightApp.adminservice.entities.Discount;
import com.flightApp.adminservice.exceptions.RecordNotFoundException;
import com.flightApp.adminservice.service.DiscountService;

@RestController
public class DiscountController {
	
	@Autowired
	private DiscountService service;
	
	
	@PostMapping("/addDiscountCoupon")
	public Discount addDiscountCoupon(@RequestBody Discount discount) {
		
		return service.saveDiscount(discount);
	}
	
	@DeleteMapping("/deleteCoupon/{id}")
	@ExceptionHandler(RecordNotFoundException.class)
	public String deleteCoupon(@PathVariable("id") Integer couponId) {
		return service.deleteDiscountCoupon(couponId);
	}

}
