package com.flightApp.adminservice.entities;

import java.io.Serializable;
import java.sql.Blob;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Flight implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3857832527101492071L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer flightId;
	private String  airlineId;
	private String  fromPlace;
	private String  toPlace;
	private Date    startDateTime;
	private Date    endDateTime;
	private Integer totalBusinessSeats;
	private Integer totalNonBusinessSeats;
	private Float   totalCost;
	private String  scheduledDays;
	private Date createdDate;
	private Date lastModifiedDate;
	private Integer createdBy;
	private Integer lastModifiedBy;
	private String  isblocked;
	private Integer statusId;
	
	

	public Flight() {
		
	}



	public Flight(String airlineId, String fromPlace, String toPlace, Date startDateTime, Date endDateTime,
			Integer totalBusinessSeats, Integer totalNonBusinessSeats, Float totalCost, String scheduledDays,
			Date createdDate, Date lastModifiedDate, Integer createdBy, Integer lastModifiedBy,String isblocked,Integer statusId) {
		super();
		this.airlineId = airlineId;
		this.fromPlace = fromPlace;
		this.toPlace = toPlace;
		this.startDateTime = startDateTime;
		this.endDateTime = endDateTime;
		this.totalBusinessSeats = totalBusinessSeats;
		this.totalNonBusinessSeats = totalNonBusinessSeats;
		this.totalCost = totalCost;
		this.scheduledDays = scheduledDays;
		this.createdDate = createdDate;
		this.lastModifiedDate = lastModifiedDate;
		this.createdBy = createdBy;
		this.lastModifiedBy = lastModifiedBy;
		this.isblocked=isblocked;
		this.statusId=statusId;
	}



	public Integer getFlightId() {
		return flightId;
	}



	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}



	public String getAirlineId() {
		return airlineId;
	}



	public void setAirlineId(String airlineId) {
		this.airlineId = airlineId;
	}



	public String getFromPlace() {
		return fromPlace;
	}



	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}



	public String getToPlace() {
		return toPlace;
	}



	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}



	public Date getStartDateTime() {
		return startDateTime;
	}



	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}



	public Date getEndDateTime() {
		return endDateTime;
	}



	public void setEndDateTime(Date endDateTime) {
		this.endDateTime = endDateTime;
	}



	public Integer getTotalBusinessSeats() {
		return totalBusinessSeats;
	}



	public void setTotalBusinessSeats(Integer totalBusinessSeats) {
		this.totalBusinessSeats = totalBusinessSeats;
	}



	public Integer getTotalNonBusinessSeats() {
		return totalNonBusinessSeats;
	}



	public void setTotalNonBusinessSeats(Integer totalNonBusinessSeats) {
		this.totalNonBusinessSeats = totalNonBusinessSeats;
	}



	public Float getTotalCost() {
		return totalCost;
	}



	public void setTotalCost(Float totalCost) {
		this.totalCost = totalCost;
	}



	public String getScheduledDays() {
		return scheduledDays;
	}



	public void setScheduledDays(String scheduledDays) {
		this.scheduledDays = scheduledDays;
	}



	public Date getCreatedDate() {
		return createdDate;
	}



	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}



	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}



	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}



	public Integer getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}



	public Integer getLastModifiedBy() {
		return lastModifiedBy;
	}



	public void setLastModifiedBy(Integer lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}



	public String getIsblocked() {
		return isblocked;
	}



	public void setIsblocked(String isblocked) {
		this.isblocked = isblocked;
	}



	public Integer getStatusId() {
		return statusId;
	}



	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}



	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", airlineId=" + airlineId + ", fromPlace=" + fromPlace + ", toPlace="
				+ toPlace + ", startDateTime=" + startDateTime + ", endDateTime=" + endDateTime
				+ ", totalBusinessSeats=" + totalBusinessSeats + ", totalNonBusinessSeats=" + totalNonBusinessSeats
				+ ", totalCost=" + totalCost + ", scheduledDays=" + scheduledDays + ", createdDate=" + createdDate
				+ ", lastModifiedDate=" + lastModifiedDate + ", createdBy=" + createdBy + ", lastModifiedBy="
				+ lastModifiedBy + "]";
	}
	

}
