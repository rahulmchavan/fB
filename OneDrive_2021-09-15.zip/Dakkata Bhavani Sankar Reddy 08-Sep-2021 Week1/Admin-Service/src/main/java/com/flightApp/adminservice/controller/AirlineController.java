package com.flightApp.adminservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.flightApp.adminservice.entities.Airline;
import com.flightApp.adminservice.exceptions.RecordAlreadyPresentException;
import com.flightApp.adminservice.exceptions.RecordNotFoundException;
import com.flightApp.adminservice.service.AirlineService;

@RestController
public class AirlineController {

	@Autowired
	private AirlineService airlineservice;

	@GetMapping("/viewAirline/{id}")
	//@Cacheable(key = "#id", value = "bookList")
	@ExceptionHandler(RecordNotFoundException.class)
	public ResponseEntity<Airline> viewAirline(@PathVariable("id") Integer airlineId) {
		try {
			 airlineservice.viewAirline(airlineId);
			 return new ResponseEntity<Airline>(airlineservice.viewAirline(airlineId),HttpStatus.OK);
		} catch (RecordNotFoundException e) {
			 return new ResponseEntity("Airline Not Found", HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/allAirline")
	@Cacheable(value="airlineList")
	public List<Airline> viewAllAirport() {
		return airlineservice.viewAllAirline();
	}

	@PostMapping("/addAirline")
	@ExceptionHandler(RecordAlreadyPresentException.class)
	public ResponseEntity<Airline> addAirline(@RequestBody Airline airline) {
		return airlineservice.addAirline(airline);
	}

	@PutMapping("/updateAirline")
	@ExceptionHandler(RecordNotFoundException.class)
	public Airline updateAirline(@RequestBody Airline airline) {
		return airlineservice.modifyAirline(airline);
	}

	@DeleteMapping("/deleteAirline/{id}")
	//@CacheEvict(key = "#id", value = "airlineList")
	@ExceptionHandler(RecordNotFoundException.class)
	public String deleteAirline(@PathVariable("id") String airlineId) {
		return airlineservice.removeAirline(airlineId);
	}
}
