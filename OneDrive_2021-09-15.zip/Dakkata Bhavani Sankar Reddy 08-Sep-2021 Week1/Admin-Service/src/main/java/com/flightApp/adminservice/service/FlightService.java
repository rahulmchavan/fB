package com.flightApp.adminservice.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.flightApp.adminservice.entities.Flight;

@Service
public interface FlightService {

	public  Flight viewFlight(Integer flightId);

	public List<Flight> viewAllFlights();

	public ResponseEntity<?> addFlight(Flight flight);

	public Flight modifyFlight(Flight flight);

	public String removeFlight(Integer flightId);
	
	public List<Flight> getFlightDetails(Flight flight);
	
	public Flight blockFlight(Integer flightId);

	
}
