package com.flightApp.adminservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.flightApp.adminservice.adminrepository.AirlineRepository;
import com.flightApp.adminservice.entities.Airline;
import com.flightApp.adminservice.exceptions.RecordNotFoundException;
import com.flightApp.adminservice.service.AirlineService;

@SpringBootTest
class AdminServiceApplicationTests {

	@Autowired
    private AirlineService service;

    @MockBean
    private AirlineRepository repo;

    // @Test
    public void testAllAirline_1(){
        List<Airline> airlineList =  service.viewAllAirline();

        System.out.println(airlineList);

        Assertions.assertSame(4, airlineList.size());
    }

    @Test
    public void testAllAirline_2(){

        Mockito.when(repo.findAll()).thenReturn(new ArrayList<Airline>());

        List<Airline> airlineList =  service.viewAllAirline();

        System.out.println(airlineList);

        Assertions.assertSame(2, airlineList.size());
    }

    @Test
    public void findByAirlineid() throws RecordNotFoundException{

        int id = 2;

        Mockito.when(repo.findById(id)).thenReturn(Optional.of(new Airline("Indigo",null,"Vizag","678936789","6E256",1)));

        Airline airline =  service.viewAirline(id);

        System.out.println(airline);


        Assertions.assertNotNull(airline);
        Assertions.assertEquals("Indigo", airline.getAirline());
        Assertions.assertEquals("Vizag", airline.getAddress());
        Assertions.assertEquals("6E256", airline.getAirlineNumber());
        Assertions.assertEquals("678936789", airline.getPhoneNumber());
    }
    @Test
    public void shouldNotFindAirlineId() throws RecordNotFoundException{

        int id = 10;

        Mockito.when(repo.findById(id)).thenThrow(new NullPointerException("Sql connection failed"));

        Assertions.assertThrows(RecordNotFoundException.class, ()->{
            service.viewAirline(id);
        });


    }
    @Test
    public void shouldNotFindAirlineByIdWithInvalidId() throws RecordNotFoundException{

        int id = 2;

        Mockito.when(repo.findById(id)).thenReturn(Optional.ofNullable(null));

        Assertions.assertThrows(RecordNotFoundException.class, ()->{
            service.viewAirline(id);
        });


    }


}
