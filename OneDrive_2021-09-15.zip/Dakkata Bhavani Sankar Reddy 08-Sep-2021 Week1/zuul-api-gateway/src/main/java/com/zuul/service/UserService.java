package com.zuul.service;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.zuul.dto.UserDTO;



@Service
public interface UserService {

	public ResponseEntity<?> createUser(UserDTO newUser);
	
	public boolean getUserExistsByUserName(String userName);
}