package com.zuul.service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.zuul.Entity.UserAdmin;
import com.zuul.dto.UserDTO;
import com.zuul.exceptions.RecordAlreadyPresentException;
import com.zuul.repository.UserRepository;






@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userDao;
	
	@Autowired
	PasswordEncoder encoder = new BCryptPasswordEncoder();
	
	@Override
	public ResponseEntity<?> createUser(UserDTO newUser) {
		// TODO Auto-generated method stub
		boolean isExistsorNot=getUserExistsByUserName(newUser.getUserName());
		if(!isExistsorNot) {
			UserAdmin admin=new UserAdmin();
			admin.setUserEmail(newUser.getUserEmail());
			admin.setUserName(newUser.getUserName());
			admin.setUserPhone(newUser.getUserPhone());
			admin.setUserType(newUser.getUserType());
			admin.setUserPassword(encoder.encode(newUser.getUserPassword()));
			try {
					userDao.save(admin);
					return new ResponseEntity<UserAdmin>(admin, HttpStatus.OK);
			} catch (RecordAlreadyPresentException e) {

				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}else {
			return new ResponseEntity<>("User is already exists with Username = "+newUser.getUserName(),HttpStatus.NOT_FOUND);
		}
		
	}

	

	@Override
	public boolean getUserExistsByUserName(String userName) {
		// TODO Auto-generated method stub
		Integer count = userDao.getUserExists(userName);
		return count!=null && count>0 ? true : false;
		
	}

}