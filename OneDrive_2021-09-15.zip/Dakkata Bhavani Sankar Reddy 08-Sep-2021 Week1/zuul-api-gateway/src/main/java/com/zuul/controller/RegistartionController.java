package com.zuul.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zuul.dto.UserDTO;
import com.zuul.exceptions.RecordAlreadyPresentException;
import com.zuul.service.UserService;


@RestController
public class RegistartionController {

	
	@Autowired
	private UserService userService;
	 
	@PostMapping("/createUser")
	@ExceptionHandler(RecordAlreadyPresentException.class)
	public ResponseEntity<Object> addUser(@RequestBody UserDTO newUser) {
		ResponseEntity<?> admin =null;
		try {
			admin=userService.createUser(newUser);
			return new ResponseEntity<Object>(admin, HttpStatus.OK);
		} catch (RecordAlreadyPresentException e) {
			 return new ResponseEntity(" User is already exists with Username="+newUser.getUserName(), HttpStatus.BAD_REQUEST);
		}
		
		
	}
}
