package com.flightApp.userservice.configurations;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerConfig {

	@Bean
    public Docket changeView(){
        return new Docket(DocumentationType.SWAGGER_2)
        .select()
        .apis(RequestHandlerSelectors.basePackage("com.flightApp"))
        .build()
        .apiInfo(getApiInfo())
        ;
    }


    private ApiInfo getApiInfo(){
        return new ApiInfoBuilder()
            .title("Flight Booking")
            .contact(new Contact("Flight App", "www.flightapp.com", "flightapp@test.com"))
            .license("MIT")
            .licenseUrl("www.licenseUrl.com")
            .version("1.0")
            .description("All custom apis are available here in this rest app")
            .build();
    }
    
	
}
