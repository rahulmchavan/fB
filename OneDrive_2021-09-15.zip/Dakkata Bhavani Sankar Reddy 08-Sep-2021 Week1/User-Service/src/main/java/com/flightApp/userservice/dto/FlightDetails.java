package com.flightApp.userservice.dto;

import java.util.Date;

public class FlightDetails {

	
	private Integer flightId;
	private String  airlineId;
	private String  fromPlace;
	private String  toPlace;
	private String    startDateTime;
	private String    endDateTime;
	private Integer totalBusinessSeats;
	private Integer totalNonBusinessSeats;
	private Float   totalCost;
	private String  scheduledDays;
	private Date createdDate;
	private Date lastModifiedDate;
	private Integer createdBy;
	private Integer lastModifiedBy;
	public Integer getFlightId() {
		return flightId;
	}
	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}
	public String getAirlineId() {
		return airlineId;
	}
	public void setAirlineId(String airlineId) {
		this.airlineId = airlineId;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public String getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}
	public String getEndDateTime() {
		return endDateTime;
	}
	public void setEndDateTime(String date) {
		this.endDateTime = date;
	}
	public Integer getTotalBusinessSeats() {
		return totalBusinessSeats;
	}
	public void setTotalBusinessSeats(Integer totalBusinessSeats) {
		this.totalBusinessSeats = totalBusinessSeats;
	}
	public Integer getTotalNonBusinessSeats() {
		return totalNonBusinessSeats;
	}
	public void setTotalNonBusinessSeats(Integer totalNonBusinessSeats) {
		this.totalNonBusinessSeats = totalNonBusinessSeats;
	}
	public Float getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(Float totalCost) {
		this.totalCost = totalCost;
	}
	public String getScheduledDays() {
		return scheduledDays;
	}
	public void setScheduledDays(String scheduledDays) {
		this.scheduledDays = scheduledDays;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(Integer lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
}
