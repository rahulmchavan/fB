package com.flightApp.userservice.dto;

import java.io.Serializable;
import java.util.List;

public class BookingDetails implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6848712441956768380L;
	private Integer pnrNumber;
	private Integer userId;
	private Integer flightId;
	private String userEmail;
	private String fromPlace;
	private String toPlace;
	private String depatureDate;
	private String arrivalDate;
	private Integer noOfSeats;
	private List<Passenger> details;
	private String isMealSelected;
	private String mealType;
	private String bookingStatus;
	private float totalFare;
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getFlightId() {
		return flightId;
	}
	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public String getDepatureDate() {
		return depatureDate;
	}
	public void setDepatureDate(String depatureDate) {
		this.depatureDate = depatureDate;
	}
	public String getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public Integer getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(Integer noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public List<Passenger> getDetails() {
		return details;
	}
	public void setDetails(List<Passenger> details) {
		this.details = details;
	}
	public String getIsMealSelected() {
		return isMealSelected;
	}
	public void setIsMealSelected(String isMealSelected) {
		this.isMealSelected = isMealSelected;
	}
	public String getMealType() {
		return mealType;
	}
	public void setMealType(String mealType) {
		this.mealType = mealType;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	
	public Integer getPnrNumber() {
		return pnrNumber;
	}
	public void setPnrNumber(Integer pnrNumber) {
		this.pnrNumber = pnrNumber;
	}
	public float getTotalFare() {
		return totalFare;
	}
	public void setTotalFare(float totalFare) {
		this.totalFare = totalFare;
	}
	public BookingDetails() {
		
	}
	
	public BookingDetails(Integer pnrNumber, Integer userId, Integer flightId, String userEmail, String fromPlace,
			String toPlace, String depatureDate, String arrivalDate, Integer noOfSeats, List<Passenger> details,
			String isMealSelected, String mealType, String bookingStatus,float totalFare) {
		super();
		this.pnrNumber=pnrNumber;
		this.userId = userId;
		this.flightId = flightId;
		this.userEmail = userEmail;
		this.fromPlace = fromPlace;
		this.toPlace = toPlace;
		this.depatureDate = depatureDate;
		this.arrivalDate = arrivalDate;
		this.noOfSeats = noOfSeats;
		this.details = details;
		this.isMealSelected = isMealSelected;
		this.mealType = mealType;
		this.bookingStatus = bookingStatus;
		this.totalFare=totalFare;
	}
	@Override
	public String toString() {
		return "BookingDetails [userId=" + userId + ", flightId=" + flightId
				+ ", userEmail=" + userEmail + ", fromPlace=" + fromPlace + ", toPlace=" + toPlace + ", depatureDate="
				+ depatureDate + ", arrivalDate=" + arrivalDate + ", noOfSeats=" + noOfSeats + ", details=" + details
				+ ", isMealSelected=" + isMealSelected + ", mealType=" + mealType + ", bookingStatus=" + bookingStatus
				+ "]";
	}
	
	

}
