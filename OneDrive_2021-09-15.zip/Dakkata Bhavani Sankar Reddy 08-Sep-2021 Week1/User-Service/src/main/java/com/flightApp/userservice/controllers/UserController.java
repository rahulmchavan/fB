package com.flightApp.userservice.controllers;


import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.flightApp.userservice.dto.BookingDetails;
import com.flightApp.userservice.dto.FlightDetails;
import com.flightApp.userservice.entities.UserAdmin;
import com.flightApp.userservice.service.UserService;



@RestController
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
    private KafkaTemplate<String, BookingDetails> kafkaTemplate;
	
	private static final String TOPIC = "kafka_topic";
	
	@GetMapping("/search/{fromPlace}/{toPlace}/{depatureDate}")
	public List<FlightDetails> search(@PathVariable("fromPlace") String from,@PathVariable("toPlace") String to,@PathVariable("depatureDate") String date){
		HttpHeaders headers = new HttpHeaders();
		 headers.add("Content-Type", "application/json");
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
		
		HttpEntity<FlightDetails> entity = new HttpEntity(null, headers);
		
		ResponseEntity<List<FlightDetails>> res = restTemplate.exchange(
			"http://ADMIN-SERVICE/getFlightDetails/"+from+"/"+to+"/"+date, 
			HttpMethod.GET, 
			entity, 
			new ParameterizedTypeReference<List<FlightDetails>>() {});
		return res.getBody();
	}
	

	@PutMapping("/updateUser")
	public void updateUser(@RequestBody UserAdmin updateUser) {
		userService.updateUser(updateUser);
	}

	

	@DeleteMapping("/deleteUser/{id}")
	public String deleteBookingByID(@PathVariable("id") Integer userId) {

		return userService.deleteUser(userId);
	}
	
	
	@PostMapping(value="/bookTicket" ,consumes = "application/json")
	public Object bookTicket(@RequestBody BookingDetails bookingdetails) {

		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<Object> entity = new HttpEntity<Object>(bookingdetails,headers);

	    ResponseEntity<Object> response = restTemplate.exchange(
	            "http://FLIGHT-SERVICE/bookTicket", HttpMethod.POST, entity, new ParameterizedTypeReference<Object>() {});
	    
	    return response.getBody();
		
	}
	
	@GetMapping("/bookingHistory/{id}")
	public List<BookingDetails> getBookingHistoryById(@PathVariable("id") Integer Id){
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<List<BookingDetails>> entity = new HttpEntity<List<BookingDetails>>(null,headers);

	    ResponseEntity<List<BookingDetails>> response = restTemplate.exchange(
	            "http://FLIGHT-SERVICE/bookingHistory/"+Id, HttpMethod.GET, entity, new ParameterizedTypeReference<List<BookingDetails>>() {});
	    
	    return response.getBody();
		
	}
	
	@GetMapping("/bookingHistoryByMail/{mail}")
	public List<BookingDetails> getBookingHistoryByMailId(@PathVariable("mail") String mail){
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<List<BookingDetails>> entity = new HttpEntity<List<BookingDetails>>(null,headers);

	    ResponseEntity<List<BookingDetails>> response = restTemplate.exchange(
	            "http://FLIGHT-SERVICE/bookingHistoryByMail/"+mail, HttpMethod.GET, entity, new ParameterizedTypeReference<List<BookingDetails>>() {});
	    
	    return response.getBody();
		
	}
	
	@GetMapping("/bookingHistoryByNumber/{pnr}")
	public List<BookingDetails> getBookingHistoryByPNRNUMBER(@PathVariable("pnr") Integer pnr){
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<List<BookingDetails>> entity = new HttpEntity<List<BookingDetails>>(null,headers);

	    ResponseEntity<List<BookingDetails>> response = restTemplate.exchange(
	            "http://FLIGHT-SERVICE/bookingHistoryByNumber/"+pnr, HttpMethod.GET, entity, new ParameterizedTypeReference<List<BookingDetails>>() {});
	    
	    return response.getBody();
		
	}
	
	@GetMapping("/cancelTicket/{pnr}")
	public BookingDetails cancelTicket(@PathVariable("pnr") BigInteger pnr){
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<BookingDetails> entity = new HttpEntity<BookingDetails>(null,headers);

	    ResponseEntity<BookingDetails> response = restTemplate.exchange(
	            "http://FLIGHT-SERVICE/cancelTicket/"+pnr, HttpMethod.GET, entity, new ParameterizedTypeReference<BookingDetails>() {});
	    
	    return response.getBody();
		
	}
	
	@GetMapping("/downloadTicket/{pnr}")
	public BookingDetails downloadTicket(@PathVariable("pnr") Integer pnr){
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<BookingDetails> entity = new HttpEntity<BookingDetails>(null,headers);

	    ResponseEntity<BookingDetails> response = restTemplate.exchange(
	            "http://FLIGHT-SERVICE/downloadTicket/"+pnr, HttpMethod.GET, entity, new ParameterizedTypeReference<BookingDetails>() {});
	    
	    return response.getBody();
		
	}
	
	@GetMapping("/cancelTicketUsingkafka/{pnr}")
    public String cancelTicketUsingkafka(@PathVariable("pnr") Integer pnr) {
		BookingDetails bookingDetails = new BookingDetails();
		bookingDetails.setPnrNumber(pnr);
		kafkaTemplate.send(TOPIC, bookingDetails);
       
        return "Ticket Canceled successfully";
    }

}