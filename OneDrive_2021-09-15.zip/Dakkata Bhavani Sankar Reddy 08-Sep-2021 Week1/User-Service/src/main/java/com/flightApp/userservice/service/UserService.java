package com.flightApp.userservice.service;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.flightApp.userservice.dto.UserDTO;
import com.flightApp.userservice.entities.UserAdmin;


@Service
public interface UserService {

	public UserAdmin updateUser(UserAdmin newUser);

	public String deleteUser(Integer UserId);

	public boolean getUserExistsByUserName(String userName);

	public ResponseEntity<?> findUserById(Integer userId);
}