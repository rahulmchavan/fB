package com.flightApp.userservice.serviceImpl;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.flightApp.userservice.dto.UserDTO;
import com.flightApp.userservice.entities.UserAdmin;
import com.flightApp.userservice.exceptions.RecordAlreadyPresentException;
import com.flightApp.userservice.exceptions.RecordNotFoundException;
import com.flightApp.userservice.repository.UserRepository;
import com.flightApp.userservice.service.UserService;





@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userDao;
	
	@Override
	public UserAdmin updateUser(UserAdmin updateUser) {
		// TODO Auto-generated method stub
		Optional<UserAdmin> findUserById = userDao.findById(updateUser.getUserId());
		if (findUserById.isPresent()) {
			userDao.save(updateUser);
		} else
			throw new RecordNotFoundException(
					"User with Id: " + updateUser.getUserId() + " not exists!!");
		return updateUser;
	}

	@Override
	public String deleteUser(Integer UserId) {
		// TODO Auto-generated method stub
		Optional<UserAdmin> findBookingById = userDao.findById(UserId);
		if (findBookingById.isPresent()) {
			userDao.deleteById(UserId);
			return "User Deleted!!";
		} else
			throw new RecordNotFoundException("User not found for the entered UserID");
	}

	

	@Override
	public ResponseEntity<?> findUserById(Integer userId) {
		// TODO Auto-generated method stub
		Optional<UserAdmin> findById = userDao.findById(userId);
		try {
			if (findById.isPresent()) {
				UserAdmin findUser = findById.get();
				return new ResponseEntity<UserAdmin>(findUser, HttpStatus.OK);
			} else
				throw new RecordNotFoundException("No record found with ID " + userId);
		} catch (RecordNotFoundException e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@Override
	public boolean getUserExistsByUserName(String userName) {
		// TODO Auto-generated method stub
		Integer count = userDao.getUserExists(userName);
		return count!=null && count>0 ? true : false;
		
	}

}